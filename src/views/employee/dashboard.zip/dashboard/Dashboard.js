import React from 'react'
import LogBoard from '../../dashboard/LogBoard'
import NoticeBoard from '../../dashboard/NoticeBoard'
import LeaveBoard from '../../dashboard/LeaveBoard'
import TimeLogSection from '../../dashboard/TimeLogSection'
import TeamTask from '../../dashboard/TeamTask'

const DefaultLayout = () => {
  const boxStyle = {
    width: '603px',
    height: '266px',
  }

  return (
    <div>

      {/* Flex row for 3 components with fixed size */}
      <div style={{ display: 'flex', gap: '20px' }}>
        <div style={boxStyle}>
          <TimeLogSection />
        </div>
        <div style={boxStyle}>
          <LogBoard />
        </div>
        <div style={boxStyle}>
          <NoticeBoard />
        </div>
      </div>


       <div style={{ display: 'flex', gap: '20px' }}>
        {/* Leave Board below the row with gap */}
      <div style={{ marginTop: '20px' }}>
        <LeaveBoard />
      </div>
      
      {/* Team Task below Leave Board with gap */}
      <div style={{ marginTop: '20px' }}>
        <TeamTask />
      </div>

       </div>
      
    </div>
  )
}

export default DefaultLayout
